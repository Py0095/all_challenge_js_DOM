let body = document.body
body.innerHTML =`<div class='wpr'><input class='cnt' name='input' id='input' type="text" maxlength=8></div>`;
const input = document.querySelector('input[name=input]')
// console.log(input.value)
// console.log(input);
input.oninput = (e) =>{
    e.preventDefault();
    // console.log(e)
    if(typeof(parseInt(e)) !== 'number'){
        console.log('li pa antye');
        input.style.borderColor ='bleu'
    }else{
        console.log('li se antye')
    }
    
        
}
// console.log(input.)


// while(typeof(e) == 'number'){
//     console.log('Is not number')
//     break;
// }

// input.onfocus = (e)=>{
//     e.preventDefault();
//     input.style.borderColor ='green'
// }input.onblur = (e) =>{
//     e.preventDefault();
//     input.style.borderColor ='black'
// }


// console.log(typeof(45))
// if(e.target.length > 8){
//     console.log(e.length);
//     input.style.borderColor = 'bleu'
//     const paran = input.parentNode;
//     console.log(paran);
//     const small = document.createElement('small')
//     const text = document.createTextNode(`small>Chan paka pran pi plis ke 8 karake`)
//     // small.style.color='red'
//     small.append(text) 
//     paran.append(small)
// // alert('A')
const countryArray =['Haiti','France','United States','Belgium','Canada','Jamaica','Mexico','Brazil','Nigeria'];

const ul = document.getElementById('ul-class')
const btn = document.getElementById('btn')


const newArray = countryArray.map((el)=>{
        ul.innerHTML+=`<li><input class='input' type="checkbox" nane="country" value="${el}">${el}</li>`
        // console.log(ul.value);
        return ul
})

btn.onclick = (e)=>{
    e.preventDefault();
    const nodeChoices = document.getElementsByClassName('input') 
    let choices = []
        for(let i = 0; i<nodeChoices.length;i++){
            if (nodeChoices[i].checked == true) {
                choices.push(nodeChoices[i].value) 
                console.log('True')
            }
}
if(choices.length !== 0){
    const div =document.getElementById('container')
    div.innerHTML =`Selection yo se: ${choices}`
}else{
    const div =document.getElementById('container')
    div.innerHTML =`Oupss!!!! oupa selectione anyn`
}

}

